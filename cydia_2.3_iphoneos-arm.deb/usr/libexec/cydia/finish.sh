#!/bin/bash

declare -a sileo
sileo=($SILEO)

if [[ ${SILEO+@} ]]; then
    eval "echo 'finish:$1' >&${sileo[0]}"
fi
